import React, { useEffect, useState } from 'react';
import ItemGrid from './components/ItemGrid';
import ItemForm from './components/ItemForm';
import { getItems, createItem, deleteItem } from './services/itemService';

const App: React.FC = () => {
  const [items, setItems] = useState([]);
  //const [setIsLoading] = useState(true);

  // useEffect(() => {
  //   loadItems();
  // }, []);

  useEffect(() => {
    const fetchItems = async () => {
      try {
        const response = await fetch('http://localhost:3001/api/items');
        if (!response.ok) {
          throw new Error(`Error: ${response.statusText}`);
        }
        const data = await response.json();
        console.log('Fetched data:', data);
        setItems(data); // Set the retrieved data to state
      } catch (error) {
        console.error('Failed to fetch items:', error);
      } finally {
       // setIsLoading(false); // Set loading to false after data is fetched
      }
    };

    fetchItems();
  }, []);

  const loadItems = async () => {
    const data = await getItems();
    setItems(data);
  };

  const handleAddItem = async (EPCID: string, Curency_Code: string, ALE: string,VI_BIN:string,VI_CIB:string,MC_BIN:string,MC_ICA:string) => {
    await createItem({ EPCID,Curency_Code, ALE ,VI_BIN,VI_CIB,MC_BIN,MC_ICA});
    loadItems();
  };

  const handleDeleteItem = async (id: number) => {
    await deleteItem(id);
    loadItems();
  };

  return (
    <div>
      <h3>Presentment Currency</h3>
      <ItemForm onSubmit={handleAddItem} />
      <ItemGrid items={items} onDelete={handleDeleteItem} />
    </div>
  );
};

export default App;