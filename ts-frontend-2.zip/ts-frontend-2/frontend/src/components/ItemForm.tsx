import React, { useState } from 'react';

interface ItemFormProps {
  onSubmit: (EPCID:string,Curency_Code: string, ALE: string,VI_BIN:string,VI_CIB:string,MC_BIN:string,MC_ICA:string) => void;
}

const ItemForm: React.FC<ItemFormProps> = ({ onSubmit }) => {
  const [EPCID, setEPCID] = useState('');
  const [Curency_Code, setCurrencyCd] = useState('');
  const [ALE, setALE] = useState('');
  const [VI_BIN, setViBin] = useState('');
  const [VI_CIB, setViCib] = useState('');
  const [MC_BIN, setMCBIN] = useState('');
  const [MC_ICA, setMCICA] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    //onSubmit(name, description);
    onSubmit(EPCID,Curency_Code, ALE,VI_BIN,VI_CIB,MC_BIN,MC_ICA);
    setEPCID('');
    setCurrencyCd('');
    setALE('');
    setViBin('');
    setViCib('');
    setMCBIN('');
    setMCICA('');
  };

  return (
    <form onSubmit={handleSubmit}>
      <input value={EPCID} onChange={(e) => setEPCID(e.target.value)} placeholder="EPC ID" required />
      <input value={Curency_Code} onChange={(e) => setCurrencyCd(e.target.value)} placeholder="Currency Code" required />
      <input value={ALE} onChange={(e) => setALE(e.target.value)} placeholder="ALE" required />
      <input value={VI_BIN} onChange={(e) => setViBin(e.target.value)} placeholder="VI BIN"/>
      <input value={VI_CIB} onChange={(e) => setViCib(e.target.value)} placeholder="VI CIB"/>
      <input value={MC_BIN} onChange={(e) => setMCBIN(e.target.value)} placeholder="MC BIN"/>
      <input value={MC_ICA} onChange={(e) => setMCICA(e.target.value)} placeholder="MC ICA"/>
      <button type="submit">+</button>
    </form>
  );
};

export default ItemForm;