import React from 'react';
import './ItemGrid.css';

interface Item {
  id: number;
  EPCID:string;
  Curency_Code: string;
  ALE: string;
  VI_BIN: string;
  VI_CIB: string;
  MC_BIN: string;
  MC_ICA: string; 
}

interface ItemGridProps {
  items: Item[];
  onDelete: (id: number) => void;
}


const ItemGrid: React.FC<ItemGridProps> = ({ items, onDelete }) => {
  return (
    // <div className="grid-container">
    //   {items.map((item) => (
    //     <div className="grid-item" key={item.id}>
    //       <h3>{item.EPCID}</h3>
    //       <p>{item.Curency_Code}</p>
    //       <p>{item.ALE}</p>
    //       <p>{item.VI_BIN}</p>
    //       <p>{item.VI_CIB}</p>
    //       <p>{item.MC_BIN}</p>
    //       <p>{item.MC_ICA}</p>
    //       <button onClick={() => onDelete(item.id)}>Delete</button>
    //     </div>
    //   ))}
    // </div>

  <div>
    <table border={1} className="table-space">
        <thead>
            <tr>
            <th className="columnWidth">ID</th>
                <th className="columnWidth">EPC ID</th>
                <th className="columnWidth">Curency Code</th>
                <th className="columnWidth">ALE</th>
                <th className="columnWidth">VI BIN</th>
                <th className="columnWidth">VI CIB</th>
                <th className="columnWidth">MC BIN</th>
                <th className="columnWidth">MC ICA</th>
            </tr>
        </thead>
        <tbody>
                    {/* Map over the data array to create rows */}
                    {items.map((row) => (
                        <tr key={row.id}>
                            {Object.values(row).map((value, index) => (
                        <td key={index}>{value}</td>
                          ))}
                          <td>
                                <button onClick={() => onDelete(row.id)}>-</button>
                            </td>
                        </tr>
                    ))}
        </tbody>
    </table>
</div>
)}

//     items.map((item) => (
//       //console.log(items.length);
//       <tr key={item.id}>
//         <td>{item.EPCID}</td>
//         <td>{item.ALE}</td>
//         <td>{item.VI_BIN}</td>
//       </tr>
//     ))
//   ) : (
//     <tr>
//       <td>No items found</td>
//     </tr>
//   )}
//  </table>
//   );
// };




// const ItemGrid: React.FC<ItemGridProps> = ({ items, onDelete }) => {
//   return (
//    //<div className="grid-container">
// <table id="dataTable" border={1}>
//             <tr>
//                 <th>Currency Code</th>
//                 <th>Desciption</th>
//             </tr>
//         <tr>
//    {items.map((item) => (
//         <div key={item.id}>
//                <td>{item.EPCID}</td>
//                <td>{item.ALE}</td>
//         </div>
//    ))}
//          </tr>
// </table>
//    // </div>
//   );
// };

// {/* <table>
//   <tr>
//     <th>Company</th>
//     <th>Contact</th>
//     <th>Country</th>
//   </tr>
//   <tr>
//     <td>Alfreds Futterkiste</td>
//     <td>Maria Anders</td>
//     <td>Germany</td>
//   </tr>
//   <tr>
//     <td>Centro comercial Moctezuma</td>
//     <td>Francisco Chang</td>
//     <td>Mexico</td>
//   </tr>
// </table> */}


// const ItemGrid: React.FC<ItemGridProps> = ({ items, onDelete }) => {
//   return (
//     {items.map((item) => (
// //{* <table id="dataTable" border="1">
//         <thead>
//             <tr>
//                 <th>{item.name}</th>
//                 <th>{item.description}</th>
//             </tr>
//         </thead>
//         <tbody>
//             <!-- Rows will be added here dynamically -->
//         </tbody>
//     </table> */}
//     ));
// };


// <!DOCTYPE html>
// <body>
//     <h2>Dynamic Table with TypeScript</h2>
//     <table id="dataTable" border="1">
//         <thead>
//             <tr>
//                 <th>ID</th>
//                 <th>Name</th>
//                 <th>Age</th>
//             </tr>
//         </thead>
//         <tbody>
//             <!-- Rows will be added here dynamically -->
//         </tbody>
//     </table>

//     <script src="main.js"></script>
// </body>
// </html>


export default ItemGrid;

// //{/* For each row, map over the values to create cells
// {Object.values(row).map((value, index) => (                      
//   <td key={index}>{value}</td>
// ))} */}

// {/* For each row, map over the values to create cells */}
// {Object.values(row).map((value, index) => (
//   <td key={index}>{value}</td>
// ))}