const API_URL = 'http://localhost:3001/api/items';

export const createItem = async (item: { EPCID: string; Curency_Code: string; ALE: string;VI_BIN: string; VI_CIB: string;MC_BIN: string; MC_ICA: string }) => {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(item),
    });
    return response.json();
  };
  
  export const getItems = async () => {
    const response = await fetch(API_URL);
    return response.json();
  };
  
  export const updateItem = async (id: number, item: { EPCID: string; Curency_Code: string; ALE: string;VI_BIN: string; VI_CIB: string;MC_BIN: string; MC_ICA: string }) => {
    const response = await fetch(API_URL + '/'+id, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(item),
    });
    return response.json();
  };
  
  export const deleteItem = async (id: number) => {
    // alert(id);
    // alert(API_URL);
    const response = await fetch(API_URL + '/'+id, {
      method: 'DELETE',
    });
    return response.json();
  };  